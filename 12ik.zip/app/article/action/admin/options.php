<?php
defined('IN_IK') or die('Access Denied.');
/* 
 * 配置选项
 */	

switch($ts){
	//基本配置
	case "":
		
		include template("admin/options");
		
		break;
}