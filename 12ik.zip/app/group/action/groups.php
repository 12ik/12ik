<?php
defined('IN_IK') or die('Access Denied.');
$title = '他的小组';
include template("groups");