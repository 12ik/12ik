<?php
defined ( 'IN_IK' ) or die ( 'Access Denied.' );

//加载风格
 

//页面
switch ($ts) {
	case "" :
				echo 111;

		
		include template("test");
		break;

}