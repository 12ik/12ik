<?php
defined('IN_IK') or die('Access Denied.');
return array(
	'name'	=> '小站',
	'version'	=> '1.0',
	'desc'	=> '如果想向大家分享某一兴趣主题的精彩内容，可以创建一个小站!',
	'url' => 'http://www.12ik.com',
	'email' => '160780470@qq.com',
	'author' => '小麦',
	'author_url' => 'http://www.12ik.com',
	'isoption'	=> '0',
	'isinstall'	=> '1',
	'issql' => '1',
	'issystem'	=> '1',
	'isappnav'	=> '1',
);