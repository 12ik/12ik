<?php
defined('IN_IK') or die('Access Denied.');
	/*
	 *包含数据库配置文件
	 */
	require_once IKDATA."/config.inc.php";
	
	$IK_APP['options']['appname'] = '动态';
	
	$skin = 'default';