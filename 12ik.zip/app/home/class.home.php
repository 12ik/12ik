<?php
defined ( 'IN_IK' ) or die ( 'Access Denied.' );

class home extends IKApp {
	
	//构造函数
	public function __construct($db) {
		parent::__construct ( $db );
	}

}
