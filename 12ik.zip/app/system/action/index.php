<?php
defined ( 'IN_IK' ) or die ( 'Access Denied.' );
/* 
 * 后台首页
 */

$title = '首页';

/*
 *包含模版
 */

include template ( "admincp" );