<?php 
defined('IN_IK') or die('Access Denied.');
class search extends ikApp{

	//构造函数
	public function __construct($db){
		parent::__construct($db);
	}

}