<?php
defined('IN_IK') or die('Access Denied.');
return array ('name' => '采集器', 'version' => '1.0', 'desc' => '采集器文章APP', 'url' => 'http://www.12ik.com', 'email' => '160780470@qq.com', 'author' => '小麦', 'author_url' => 'http://www.12ik.com', 'isoption' => '1', 'isinstall' => '1', 'issql' => '1', 'issystem' => '1', 'isappnav' => '0' );