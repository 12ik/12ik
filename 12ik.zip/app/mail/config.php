<?php
defined('IN_IK') or die('Access Denied.');
	/*
	 *包含数据库配置文件
	 *如果要单独配置请去除包含数据库配置文件，并将数据库配置信息粘贴在此处
	 */
	require_once IKDATA."/config.inc.php";
