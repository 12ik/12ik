<?php 
defined('IN_IK') or die('Access Denied.');
tsNotice('呃哦...你想访问的页面不存在！');