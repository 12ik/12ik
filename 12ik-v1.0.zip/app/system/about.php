<?php
defined ( 'IN_IK' ) or die ( 'Access Denied.' );
return array ('name' => '系统管理', 'version' => '1.0', 'desc' => '管理所有APP', 'url' => 'http://www.12ik.com', 'email' => '160780470@qq.com', 'author' => '小麦', 'author_url' => 'http://www.12ik.com', 'isoption' => '0', 'isinstall' => '1', 'issql' => '1', 'issystem' => '1', 'isappnav' => '0' );