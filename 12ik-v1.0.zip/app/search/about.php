<?php
defined('IN_IK') or die('Access Denied.');
return array(
	'name'	=> '搜索',
	'version'	=> '1.0',
	'desc'	=> '搜索话题，小站，小组，成员，日志等',
	'url' => 'http://www.12ik.com',
	'email' => '160780470@qq.com',
	'author' => '小麦',
	'author_url' => 'http://www.12ik.com',
	'isoption'	=> '0',
	'isinstall'	=> '1',
	'issql' => '1',
	'issystem'	=> '1',
	'isappnav'	=> '0',
);