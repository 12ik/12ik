<?php
defined('IN_IK') or die('Access Denied.');

require_once IKDATA."/config.inc.php";

$skin = 'default';