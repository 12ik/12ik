<?php
defined('IN_IK') or die('Access Denied.');
$skin = 'default';
require_once IKDATA.'/config.inc.php';
	
$IK_APP['options']['appname'] = '相册';