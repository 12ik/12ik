<?php
defined('IN_IK') or die('Access Denied.');

class haomiwo extends IKApp{

	//构造函数
	public function __construct($db){
		parent::__construct($db);
	}

	
	//析构函数
	public function __destruct(){
		
	}
					
}