﻿<?php
defined('IN_IK') or die('Access Denied.');
return array(
	'name'	=> '好米窝',
	'version'	=> '1.0',
	'desc'	=> '一个出售域名的地方',

);