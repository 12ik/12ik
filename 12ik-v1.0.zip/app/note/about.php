<?php
defined('IN_IK') or die('Access Denied.');
return array(
	'name'	=> '日志',
	'version'	=> '1.0',
	'desc'	=> '日志，博客，文章',
	'url' => 'http://www.12ik.com',
	'email' => '160780470@qq.com',
	'author' => '小麦',
	'author_url' => 'http://www.12ik.com',
	'isoption'	=> '1',
	'isinstall'	=> '1'
);